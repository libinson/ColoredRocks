<?php
/*
Plugin Name:  extplorer
Plugin URI: http://www.jewelosman.com
Description: Wordpress file manager
Version: 2.1.5
Author: JewelOsman
Author URI: http://www.jewelosman.com
Plugin URI: http://www.jewelosman.com
*/


// no direct access
#defined( '_JEXEC' ) or die( 'Restricted access' );

function extplorer_show(){

print "<iframe src='../wp-content/plugins/extplorer/index.php' width='100%' height='900' frameborder=0 marginWidth=0 frameSpacing=0 marginHeight=110 ></iframe>";

}
function extplorer_install(){

}

function extplorer_page(){

	if ( function_exists('add_submenu_page') )
		add_submenu_page('plugins.php', eXtplorer, eXtplorer, 'manage_options', 'extplorer_show', 'extplorer_show');



}

#add_action('admin_head', 'extplorer');
add_action('admin_menu', 'extplorer_page');

#add_options_page('eXtplorer Options', 'eXtplorer', 9, 'index.php', 'extplorer_options');

if (isset($_GET['activate']) && $_GET['activate'] == 'true')
 {
   add_action('init', 'extplorer_install');
 }

?>
